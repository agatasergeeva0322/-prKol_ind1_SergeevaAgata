﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace winForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Queue<Student> students = new Queue<Student>();
            if (File.Exists("wf_z2_9.txt"))
            {
                string[] lines = File.ReadAllLines("wf_z2_9.txt");
                if (!(lines.Length==0))
                {
                    Student person = new Student("", "", "", 0, 0, 0, 0);
                    foreach (string line in lines)
                    {
                        string[] chelovek = line.Split(' ');
                        string lastname = chelovek[0];
                        person.set_lastname(lastname);
                        string name = chelovek[1];
                        person.set_name(name);
                        string otfather = chelovek[2];
                        person.set_otfather(otfather);
                        int num_group = Convert.ToInt32(chelovek[3]);
                        person.set_num_group(num_group);
                        int mark1 = Convert.ToInt32(chelovek[4]);
                        person.set_mark1(mark1);
                        int mark2 = Convert.ToInt32(chelovek[5]);
                        person.set_mark2(mark2);
                        int mark3 = Convert.ToInt32(chelovek[6]);
                        person.set_mark3(mark3);
                        students.Enqueue(new Student(lastname, name, otfather, num_group, mark1, mark2, mark3));
                    }
                    var good_st = from p in students
                                  where p.get_mark1() > 2 && p.get_mark2() > 2 && p.get_mark3() > 2
                                  select p;
                    foreach (var a in good_st)
                    {
                        listBox1.Items.Add($"{a.get_lastname()} {a.get_name()} {a.get_otfather()}, группа ПР-{a.get_num_group()}");
                        listBox1.Items.Add("Экзамены:");
                        listBox1.Items.Add($"Теория вероятностей: {a.get_mark1()}");
                        listBox1.Items.Add($"Основы алгоритмизации: {a.get_mark2()}");
                        listBox1.Items.Add($"РМП: {a.get_mark3()}");
                        listBox1.Items.Add("");

                    }
                    var bad_st = from p in students
                                 where p.get_mark1() == 2 && p.get_mark2() == 2 && p.get_mark3() == 2
                                 select p;
                    foreach (var a in bad_st)
                    {
                        listBox2.Items.Add($"{a.get_lastname()} {a.get_name()} {a.get_otfather()}, группа ПР-{a.get_num_group()}");
                        listBox2.Items.Add($"Теория вероятностей: {a.get_mark1()}");
                        listBox2.Items.Add($"Основы алгоритмизации: {a.get_mark2()}");
                        listBox2.Items.Add($"РМП:{a.get_mark3()}");
                        listBox2.Items.Add("");
                    }
                }
                else MessageBox.Show("Файл 'wf_z2_9' пустой! Заполните его и возвращайтесь", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("Файл 'wf_z2_9' не найден","Ошибка",MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Stack<int> first_part = new Stack<int>();
            Stack<int> second_part = new Stack<int>();
            Random rnd = new Random();
            int max;
            int min;
            int itog;
            string Mm = "", mM = "";
            if (File.Exists("wf_z1_8.txt"))
            {
                string p = File.ReadAllText("wf_z1_8.txt");
                if (!string.IsNullOrEmpty(p))
                {
                    int ind = p.IndexOf("<");
                    int num = Convert.ToInt32(p[ind + 1]) - 48;
                    int i = 0;
                    while (i < num)
                    {
                        first_part.Push(rnd.Next(0, 9));
                        second_part.Push(rnd.Next(0, 9));
                        i++;
                    }
                    switch (comboBox2.SelectedIndex)
                    {
                        case 0:
                            {
                                max = first_part.Max();
                                min = second_part.Min();
                                if (min > max) itog = min;
                                else itog = max;
                                while (first_part.Count > 0)
                                {
                                    Mm += $"{first_part.Pop()} ";
                                    mM += $"{second_part.Pop()} ";
                                }
                                textBox1.Text = $"M(M({Mm}), m({mM}) = {itog}";
                                break;
                            }
                        case 1:
                            {
                                max = first_part.Max();
                                min = second_part.Max();
                                if (min > max) itog = min;
                                else itog = max;
                                while (first_part.Count > 0)
                                {
                                    Mm += $"{first_part.Pop()} ";
                                    mM += $"{second_part.Pop()} ";
                                }
                                textBox1.Text = $"M(M({Mm}), M({mM}) = {itog}";
                                break;
                            }
                        case 2:
                            {
                                max = first_part.Min();
                                min = second_part.Min();
                                if (min > max) itog = min;
                                else itog = max;
                                while (first_part.Count > 0)
                                {
                                    Mm += $"{first_part.Pop()} ";
                                    mM += $"{second_part.Pop()} ";
                                }
                                textBox1.Text = $"M(m({Mm}), m({mM}) = {itog}";
                                break;
                            }
                        case 3:
                            {
                                max = first_part.Max();
                                min = second_part.Min();
                                if (min < max) itog = min;
                                else itog = max;
                                while (first_part.Count > 0)
                                {
                                    Mm += $"{first_part.Pop()} ";
                                    mM += $"{second_part.Pop()} ";
                                }
                                textBox1.Text = $"m(M({Mm}), m({mM}) = {itog}";
                                break;
                            }
                        case 4:
                            {
                                max = first_part.Max();
                                min = second_part.Max();
                                if (min < max) itog = min;
                                else itog = max;
                                while (first_part.Count > 0)
                                {
                                    Mm += $"{first_part.Pop()} ";
                                    mM += $"{second_part.Pop()} ";
                                }
                                textBox1.Text = $"m(M({Mm}), M({mM}) = {itog}";
                                break;
                            }
                        case 5:
                            {
                                max = first_part.Min();
                                min = second_part.Min();
                                if (min < max) itog = min;
                                else itog = max;
                                while (first_part.Count > 0)
                                {
                                    Mm += $"{first_part.Pop()} ";
                                    mM += $"{second_part.Pop()} ";
                                }
                                textBox1.Text = $"m(m({Mm}), m({mM}) = {itog}";
                                break;
                            }
                    }
                }
                else MessageBox.Show("Файл 'wf_z1_8' пустой! Заполните его и возвращайтесь", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("Файл 'wf_z1_8' не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            MessageBox.Show("Я использовала LINQ ТОЛЬКО  в задаче 2(9), потому что только в этом задании увидела нужность запроса\nПростите меня, если я дурак", "Внимание!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}



