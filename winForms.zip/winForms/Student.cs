﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace winForms
{
    class Student
    {
        private string lastname;
        private string name;
        private string otfather;
        private int num_group;
        private int mark1;
        private int mark2;
        private int mark3;

        public Student(string lastname, string name, string otfather, int num_group, int mark1, int mark2, int mark3)
        {
            this.lastname = lastname;
            this.name = name;
            this.otfather = otfather;
            this.num_group = num_group;
            this.mark1 = mark1;
            this.mark2 = mark2;
            this.mark3 = mark3;
        }
        public void set_lastname(string n)
        {
            this.lastname = n;
        }
        public string get_lastname()
        {
            return lastname;
        }
        public void set_name(string n)
        {
            this.name = n;
        }
        public string get_name()
        {
            return this.name;
        }
        public void set_otfather(string n)
        {
            this.otfather = n;
        }
        public string get_otfather()
        {
            return this.otfather;
        }
        public void set_num_group(int n)
        {
            this.num_group = n;
        }
        public int get_num_group()
        {
            return this.num_group;
        }
        public void set_mark1(int n)
        {
            this.mark1 = n;
        }
        public double get_mark1()
        {
            return this.mark1;
        }
        public void set_mark2(int n)
        {
            this.mark2 = n;
        }
        public double get_mark2()
        {
            return this.mark2;
        }
        public void set_mark3(int n)
        {
            this.mark3 = n;
        }
        public double get_mark3()
        {
            return this.mark3;
        }
    }
}
